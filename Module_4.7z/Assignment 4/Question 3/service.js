app.service("DataService", function($http){
    this.getData = function () {
        return $http.get("order.txt");
    }
});

app.service("DetailedDataService", function ($http) {
    this.getData = function () {
        return $http.get("orderDetails.txt");
    }
});