app.controller("HttpController", function ($scope, DataService, DetailedDataService) {
    var response = DataService.getData();
    response.success(function (data) {
        $scope.orderData = data.orders;
    });
    $scope.DisplayDetails = function (orderno) {
        var detailedresponse = DetailedDataService.getData();
        detailedresponse.success(function (data) {
            $scope.orderDetails = data.orders[orderno - 1];
        });
    }
    
});