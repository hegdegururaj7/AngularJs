app.service("DataService", function($http){
    this.getData = function () {
        return $http.get("order.txt");
    }
});