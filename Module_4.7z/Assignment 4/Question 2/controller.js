app.controller("HttpController", function($scope, DataService){
    var response = DataService.getData();
    response.success(function (data) {
        $scope.orderData = data.orders;
    });
    
});