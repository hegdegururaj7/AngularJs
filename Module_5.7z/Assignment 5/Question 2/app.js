var app = angular.module("AutoSuggestApp", []);

app.controller("MyCtrl", function($scope){
    $scope.data = ["World", "Earth", "Water", "Land", "Fire", "Air"];
    $scope.suggest = function(){
        $scope.Show = "true";
    }
    $scope.select = function(value){
        $scope.selected = value;
        $scope.Hide = "true";
    }
});

app.directive("autoSuggest", function(){
    return {
        template : "<div style='background-color:aliceblue; width:fit-content'>"
            +"<h5 ng-repeat='i in data | filter : selected' ng-show='Show'>"
                +"<p ng-click='select(i)' ng-hide='Hide'>{{i}}</p></h5></div>"
    }
});
