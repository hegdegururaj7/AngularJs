var app = angular.module("AutoSuggestApp", []);

app.controller("MyCtrl", function($scope){
    $scope.data = ["Mobile", "Tablet", "Desktop", "Laptop"," Server"];
    $scope.details = [
            {"orderno":"1", "pname":"Mobile", "pquantity":"500", "price":"15000", "date":"2017-01-01", "state":"pending"},
            {"orderno":"2", "pname":"Tablet","pquantity":"1000", "price":"30000", "date":"2010-11-01", "state":"active"},
            {"orderno":"3", "pname":"Desktop", "pquantity":"50", "price":"50000", "date":"2017-05-01", "state":"new"},
            {"orderno":"4", "pname":"Laptop", "pquantity":"250", "price":"55000", "date":"2017-12-01", "state":"pending"},
            {"orderno":"5", "pname":"Server", "pquantity":"1", "price":"100000", "date":"2007-08-15", "state":"active"}
        ];

    $scope.suggest = function(){
        $scope.Show = "true";
    }
    $scope.select = function(value){
        $scope.selected = value;
        $scope.Hide = "true";
    }
    $scope.search = function(){
        for(i in $scope.details){
            if($scope.details[i].pname == $scope.selected){
                $scope.ShowTable = "true";
                $scope.selectedData = $scope.details[i];
            }
        }
    }
});

app.directive("autoSuggest", function(){
    return {
        template : "<div style='background-color:aliceblue; width:fit-content'>"
            +"<h5 ng-repeat='i in data | filter : selected' ng-show='Show'>"
                +"<p ng-click='select(i)' ng-hide='Hide'>{{i}}</p></h5></div>"
    }
});
