var app = angular.module('CustomDirectiveApp', []); 

app.directive("modalDirective", function () {
  return {
    template : "<div id='myModal' class='modal'>"
        +"<div class='modal-content'>"
        +"<p>This is a modal</p>"
        +"</div></div>"
  }
});

app.controller("ModalCtrl", function($scope){
  $scope.openModal = function(){
      var modal = document.getElementById('myModal');
      modal.style.display = "block";
  }
});