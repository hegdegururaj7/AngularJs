var app = angular.module("SharingData", []);

app.service("DataService", function(){
    this.empData = [{eid:1, ename:"Chandler", edep:"Accounting"},
                   {eid:2, ename:"Joey", edep:"Food"},
                   {eid:3, ename:"Ross", edep:"Paleontology"}];
});

app.controller("CRUDCtrl", function($scope, DataService){
    $scope.AddEmployee = function(){
        DataService.empData.push($scope.emp);
        $scope.emp = {};
    }

    $scope.AdditionalFields = false;
    $scope.ShowAdditionalFields = function(){
        $scope.AdditionalFields = true;
    }

    $scope.UpdateEmployee  = function(){
        for(i in DataService.empData){
            if(DataService.empData[i].eid == $scope.ueid){
                DataService.empData[i] = {'eid':$scope.ueid, 'ename': $scope.uename, 'edep':$scope.uedep};
            }
        }
    }    

    $scope.DeleteEmployee  = function(){
        for(i in DataService.empData){
            if(DataService.empData[i].eid == $scope.deid){
                DataService.empData.splice(i,1);
            }
        }
    } 
});

app.controller("DisplayCtrl", function($scope, DataService){
    $scope.EmployeeDetails = DataService.empData;
});