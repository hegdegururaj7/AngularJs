var app = angular.module("InheritanceDemo",[]);
        
        app.controller("MasterCtrl", function($scope){
            $scope.products = [{name:"Mobile", price:"15000"},{name:"Laptop", price:"30000"}, {name:"Desktop", price:"50000"}];
            $scope.determinePrice = function(){
                for(i in $scope.products){
                    console.log($scope.products[i].name +""+$scope.pname.name);
                    if($scope.products[i].name == $scope.pname.name){
                        $scope.pprice = $scope.products[i].price;
                    }
                }
            }
        });

        app.controller("ChildCtrl", function($scope){
           $scope.calculate = function(){
               $scope.total = $scope.pprice * $scope.pquantity;
           }
        })