var app = angular.module("ServiceDemo", []);

app.service("LoginCheck", function(){
    this.check = function(username, password){
        if(username == "admin" && password == "123"){
            return "Welcome This is the administrator account";
        }else{
            return "Invalid Username/Password"
        }
    }
});

app.controller("loginCtrl", function($scope, LoginCheck){
    $scope.validate = function(){
        $scope.message = LoginCheck.check($scope.username, $scope.password);
    }
});