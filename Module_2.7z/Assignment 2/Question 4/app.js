var app = angular.module("DependancyApp", []);

app.factory("AuthenticationFactory", function(){
    var authenticateUser = function(username, password){
        if(username=="admin" && password=="123"){
            return true;
        }else{
            return false;
        }
    }

    return {callFunc : authenticateUser};
});

app.factory("OrderFactory", ['AuthenticationFactory', function(AuthenticationFactory){
    var orderData = [{orderno:"1", pname:"Mobile", pquantity:"500"},
                     {orderno:"2", pname:"Tablet", pquantity:"1000"},
                     {orderno:"3", pname:"Desktop", pquantity:"50"}
                     ];
    var getOrderDetails = function(orderNo, username, password){
        if(AuthenticationFactory.callFunc(username, password)){
            for(i in orderData){
                if(orderNo == orderData[i].orderno){
                    return orderData[i];
                }
            }
        }else{
            return false;
        }
    }
    return {callFunc : getOrderDetails};
}]);

app.controller("DispCtrl", function($scope, OrderFactory){
    $scope.ShowDetails = false;
    $scope.login = function(){
        if($scope.username !=undefined && $scope.password != undefined)
           $scope.ShowDetails = true;
           $scope.DisplayDetails = "";
    }
    $scope.getDetails = function(orderno, username, password){
        var orderObj = OrderFactory.callFunc(orderno, username, password);
        if(orderObj != false)
            $scope.DisplayDetails = "Order No: "+ orderObj.orderno + " | Product: " + orderObj.pname + " | Quantity: " + orderObj.pquantity;
        else
            $scope.DisplayDetails = "The user " + username + " is not authenticated. Login again with the correct credentials";
    }
});

