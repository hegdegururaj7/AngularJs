var app = angular.module("FactoryDemo", ['ngSanitize']);

app.factory("OrderFactory", function(){
    var orderData = [{orderno:"1", pname:"Mobile", pquantity:"500"},
                     {orderno:"2", pname:"Tablet", pquantity:"1000"},
                     {orderno:"3", pname:"Desktop", pquantity:"50"},
                     {orderno:"4", pname:"Laptop", pquantity:"250"},
                     {orderno:"5", pname:"Server", pquantity:"1"}
                     ];
    
    var result =  function(ordernoVal){
        for(i in orderData){
            console.log(orderData[i].orderno);
            if(ordernoVal == orderData[i].orderno){
                console.log(orderData[i].pname);
                return orderData[i];
            }
        }
    };
    return {callFunction : result};
});

app.controller("SearchOrder", function($scope, OrderFactory){
    $scope.Search = function(orderno){
        var resultObj = OrderFactory.callFunction(orderno);
        $scope.orderDetails = "<br /><b>Order Details</b><br /><br />"
        +"<table border='3px'><tr><td>"+resultObj.orderno+"</td><td>"+resultObj.pname+"</td><td>"+resultObj.pquantity+"</td></tr></table>"
    }
    
});