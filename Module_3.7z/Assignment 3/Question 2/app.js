var app = angular.module("FilterApp", []);

app.factory("OrderFactory", function(){
   var orderData = [{orderno:"1", pname:"Mobile", pquantity:"500", price:15000, date:"2017-01-01", state:"pending"},
                     {orderno:"2", pname:"Tablet", pquantity:"1000", price:30000, date:"2010-11-01", state:"active"},
                     {orderno:"3", pname:"Desktop", pquantity:"50", price:50000, date:"2017-05-01", state:"new"},
                     {orderno:"4", pname:"Laptop", pquantity:"250", price:55000, date:"2017-12-01", state:"pending"},
                     {orderno:"5", pname:"Server", pquantity:"1", price:100000, date:"2007-08-15", state:"active"}
                     ];
    
    var getOrders = function(){
        return orderData;
    }
    return {callFunc : getOrders};
});

app.controller("FilterCtrl", function($scope, OrderFactory){
    $scope.DisplayOrder = OrderFactory.callFunc();
});