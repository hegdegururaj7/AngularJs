var app = angular.module("RoutingApp", ['ngRoute']);

app.config(function($routeProvider){
    $routeProvider.when("/", {
        controller:"HomeController",
        templateUrl: "/"
    })
    .when("/user", {
        controller:"userCtrl",
        templateUrl: "user.html"
    })
    .when("/admin", {
        controller:"adminCtrl",
        templateUrl: "admin.html"
    })
    .when("/home", {
        controller:"userHomeCtrl",
        templateUrl: "home.html"
    })
    .when("/aboutus", {
        controller:"aboutusCtrl",
        templateUrl: "aboutus.html"
    })
    .when("/contact", {
        controller:"contactCtrl",
        templateUrl: "contact.html"
    })
    .when("/adminhome", {
        controller:"adminhomeCtrl",
        templateUrl: "adminhome.html"
    })
    .when("/adminabout", {
        controller:"adminaboutCtrl",
        templateUrl: "adminabout.html"
    })
    .when("/admincontact", {
        controller:"admincontactCtrl",
        templateUrl: "admincontact.html"
    });
});

app.service("AuthenticationService", function($location, $window){
    this.LoginCheck = function(username, password){
        if(username == "admin" && password == "123")
            //$window.location.href = "admin.html";
            $location.path("admin");
        else if(username == "user" && password == "enter")
            //$window.location.href = "user.html"
            $location.path("user");
        else{
            alert("Invalid Username/Password");
            $location.path("/");
        }
    }
});

app.controller("HomeController", function($scope, AuthenticationService){
    $scope.LoginCheck = function(){
        AuthenticationService.LoginCheck($scope.username, $scope.password);
    }
});

app.controller("userCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("adminCtrl", function($scope){
    $scope.message = "Welcome Admin";
});

app.controller("userHomeCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("aboutusCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("contactCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("adminhomeCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("adminaboutCtrl", function($scope){
    $scope.message = "Welcome User";
});

app.controller("admincontactCtrl", function($scope){
    $scope.message = "Welcome User";
});