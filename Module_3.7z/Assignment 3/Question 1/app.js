var app = angular.module("DirectivesApp", ['ngRoute']);

app.config(function($routeProvider){
    $routeProvider.when("/", {
        controller:"DirectiveController",
        templateUrl: "/"
    })
    .when("/user", {
        controller:"userCtrl",
        templateUrl: "user.html"
    })
    .when("/admin", {
        controller:"adminCtrl",
        templateUrl: "admin.html"
    });
});

app.service("AuthenticationService", function($location){
    this.LoginCheck = function(username, password){
        if(username == "admin" && password == "123")
            $location.path("admin");
        else if(username == "user" && password == "enter")
            $location.path("user");
        else{
            alert("Invalid Username/Password");
            $location.path("/");
        }
    }
});

app.factory("OrderFactory", function(){
    var orderData = [{orderno:"1", pname:"Mobile", pquantity:"500", state:"pending"},
                     {orderno:"2", pname:"Tablet", pquantity:"1000", state:"active"},
                     {orderno:"3", pname:"Desktop", pquantity:"50", state:"new"},
                     {orderno:"4", pname:"Laptop", pquantity:"250", state:"pending"},
                     {orderno:"5", pname:"Server", pquantity:"1", state:"active"}
                     ];
    
    var result =  function(){
        return orderData;
    };
    return {callFunction : result};
});

app.controller("DisplayOrder", function($scope, OrderFactory){
        $scope.resultObj = OrderFactory.callFunction();
});

app.controller("DirectiveController", function($scope, AuthenticationService){
    $scope.LoginCheck = function(){
        AuthenticationService.LoginCheck($scope.username, $scope.password);
    }
});

app.controller("userCtrl", function($scope){
    $scope.message = "Welcome User";
})

app.controller("adminCtrl", function($scope){
    $scope.message = "Welcome Admin";
})