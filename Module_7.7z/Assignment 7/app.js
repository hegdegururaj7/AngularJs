var app=angular.module("TestingApp",['ngRoute']);

app.controller("testController",function($scope){
    $scope.title="Module 7 Assignment";
});

function testCase1()
{
    return "Hello, World";
}
function testCase2()
{
    return 30+70;
}

app.factory('ArrayFactory', function() {
  var lng = {},
    response = [{"id":"1", "Name":"Robert Langdon"}, 
                {"id":"2", "Name":"Arthur Curry"}];

  lng.get = function() {
    return response;
  }

  return lng;
});


app.directive('myDir', function() {
  return {
    restrict: 'E',
    template: '<div>Hello {{name}}</div>',
    replace: false
  };
});
app.factory('LanguagesServicePromise', ['$http', '$q', function($http, $q) {
  var lng = {};

  lng.get = function() {
    var deferred = $q.defer();
    $http.get('languages.json')
      .then(function(response) {
        var languages = response.data.map(function(item) {
          return item.name;
        });
        deferred.resolve(languages);
      })
      .catch(function(response) {
        deferred.reject(response);
      });
    return deferred.promise;
  }

  return lng;
}]);