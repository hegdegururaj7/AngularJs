describe("TestCase1", function() {
  it("Welcome to AngularJS course of toEqual", function() {
    expect(testCase1()).toEqual("Hello, World");
  });
});
describe("TestCase2", function() {
  it("ToBe Test Case", function() {
    expect(testCase2()).toEqual(100);
  });
});

describe('Test Case 3', function() {

  describe('Factory', function() {
    var ArrayFactory;

    beforeEach(function() {
      module('TestingApp');
      inject(function($injector) {
        ArrayFactory = $injector.get('ArrayFactory');
      });
    });

    it('returns array of objects from array', function() {
      var arr = ArrayFactory.get();
      expect(arr.length).toEqual(2);
      expect(arr).toContain(jasmine.objectContaining({Name: 'Robert Langdon' }));
      expect(arr).toContain(jasmine.objectContaining({id: '1' }));

    });
  });

});

  describe('Test Case 4', function() {
    var element,
      name = 'Bond';
    beforeEach(function() {
      module('TestingApp');
      element = angular.element('<my-dir/>');
      inject(function($rootScope, $compile) {
        var scope = $rootScope.$new();
        scope.name = name;
        $compile(element)(scope);
        scope.$digest();
      });
    });
    it('says Hello Bond', function() {
      expect(element.text()).toBe('Hello Bond');
    });
  });
describe('Test Case 5', function() {
  describe('HTTP Service', function() {
    var LanguagesServicePromise,
      $httpBackend,
      jsonResponse = [{
        "name": "Bruce Wayne"
      }, {
        "name": "Clark Kent"
      }, {
        "name": "Diana Prince"
      }];

    beforeEach(function() {
      module('TestingApp');
      inject(function($injector) {
        LanguagesServicePromise = $injector.get('LanguagesServicePromise');
        // set up the mock http service
        $httpBackend = $injector.get('$httpBackend');

        // backend definition common for all tests
        $httpBackend.whenGET('languages.json')
          .respond(jsonResponse);
      });
    });

    it('should return available languages from json file', function(done) {
      // service returns a promise
      var promise = LanguagesServicePromise.get();
      // use promise as usual
      promise.then(function(languages) {
        // same tests as before
        expect(languages).toContain('Bruce Wayne');
        expect(languages).toContain('Clark Kent');
        expect(languages).toContain('Diana Prince');
        expect(languages.length).toEqual(3);
        // Spec waits till done is called or Timeout kicks in
        done();
      });
      // flushes pending requests
      $httpBackend.flush();
    });
  });

});