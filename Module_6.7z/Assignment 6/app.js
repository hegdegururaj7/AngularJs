var app = angular.module("BootstrapApp", ['ngSanitize']);

app.controller("DemoApp", function($scope, getorder, getOffers, getTabInfo, getCustomers) {
  $scope.suggest = function(){
        $scope.Show = "true";
  }
  $scope.select = function(value){
        $scope.selected = value;
        $scope.Hide = "true";
    }
  $scope.orders = getorder();
  $scope.offers = getOffers();
  $scope.tabs = getTabInfo();
  $scope.customers = getCustomers();
  
});
app.factory('getorder', function($http) { 
  return function() {
    var order = [{
      "orderid": "1",
      "customer": "Jack",
      "location": "NY"
    }, {
      "orderid": "2",
      "customer": "Logan",
      "location": "WH"
    }, {
      "orderid": "3",
      "customer": "Zack",
      "location": "TX"
    }, {
      "orderid": "4",
      "customer": "Joey",
      "location": "TN"
    }];
    return order;
  };
});

app.factory('getOffers', function($http) {
  return function() {
    var offer = [{
      "slide": "0",
      "img": "Desert.jpg",
      "caption": "Desert"
    }, {
      "slide": "1",
      "img": "Koala.jpg",
      "caption": "Koala"
    }, {
      "slide": "2",
      "img": "Penguins.jpg",
      "caption": "Penguins"
    }];   
    return offer;
  };
});

app.factory('getTabInfo', function($http) { 
  return function() {
    var tab = [{
      "id": "tab1",
      "name": "Tab 1",
      "content": "Hello, World",
      "bg": "#2196F3"
    }, {
      "id": "tab2",
      "name": "Tab 2",
      "content": "Hello, Ceres",
      "bg": "#EF5350"
    }, {
      "id": "tab3",
      "name": "Tab 3",
      "content": "Hello, Mars",
      "bg": "#66BB6A"
    }];  
    return tab;
  };
});

app.factory('getCustomers', function($http) {
  return function() {
    var customer = [{
      "company": "Google"
    }, {
      "company": "Microsoft"
    }, {
      "company": "Tesla"
    }, {
      "company": "Apple"
    }, {
      "company": "IBM"
    }, {
      "company": "HyperLoop"
    }];
    return customer;
  };
});